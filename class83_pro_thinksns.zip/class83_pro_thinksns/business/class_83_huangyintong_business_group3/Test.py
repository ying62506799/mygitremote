from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time
# driver = webdriver.Chrome()
# driver.get("http://203.195.235.31/thinksns/index.php?s=/Index/reg")
# # s1 = Select(driver.find_element_by_name("birthday_year"))
# # s1.select_by_value("1950")
# driver.find_element_by_xpath("/html/body/div[2]/form/ul[2]/li[4]/div[2]/input[3]").click()
# time.sleep(2)
# print(len(driver.find_elements_by_xpath("//ul[@id='list_1']/li")))
# # driver.find_element_by_link_text("山西").click()
# # time.sleep(2)
# # print(len(driver.find_elements_by_xpath("//ul[@id='list_2']/li")))
# #所有的省份 /html/body/div[9]/div[2]/div[2]/div/div/div/div/div[1]/div[1]/div[1]/ul/li
# # 点之后所有的 县区/html/body/div[9]/div[2]/div[2]/div/div/div/div/div[1]/div[1]/div[2]/ul/li/a
# import xlrd
# 
# 
# import xlsxwriter
# 
# xls2 = xlsxwriter.Workbook(r'D:\\\\develop\\\\pythondevelop\\\\eclipse-jee-oxygen-3a-win32-x86_64\\\\pythonworkplace\\\\class83_pro_thinksns\\\\datadriver\\\\regisdata\\\\123.xlsx')
# sht2 = xls2.add_worksheet()
# sht2.write(0,0,"列1")

# xlsfile = 'D:\\\\develop\\\\pythondevelop\\\\eclipse-jee-oxygen-3a-win32-x86_64\\\\pythonworkplace\\\\class83_pro_thinksns\\\\datadriver\\\\regisdata\\\\123.xlsx'
# book = xlrd.open_workbook(xlsfile)
# sheet_name = book.sheet_names()
# print(sheet_name)
# 
# sheet = book.sheet_by_index(1)
# nrows = sheet.nrows
# ncols = sheet.ncols
# print(nrows)
# print(ncols)
# 
# row_data = sheet.row_values(0)
# col_data = sheet.col_values(0)
# print(row_data)
# print(col_data)
# 
# cell_value = sheet.cell_value(3,0)
# print(cell_value)
# cell_value2 = sheet.cell(3,0)
# print(cell_value2)
# 
# sheet.put_cell(1,2,1,"test",0)
# cell_value2 = sheet.cell(1,1)
# print(cell_value2)
# 
# #保存xlsfile
# wb = copy(book)
# wb.save(xlsfile)
import os
from tools import getTC
# print(os.listdir("D:\\testing\\eclipse\\workplace\\class83_pro_thinksns\\src"))

path1 = os.getcwd().split("business")[0]+"datadriver\\driver_type\\users.xlsx"
list1 = getTC.get_testdata_by_excel(path1,"Sheet1")
print(list1)