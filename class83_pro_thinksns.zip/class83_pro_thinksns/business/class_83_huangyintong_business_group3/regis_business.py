'''
Created on 2018年6月10日

@author: hyt
'''
from selenium import webdriver
import time
import tools.Wait
import os
from selenium.webdriver.common.by import By
from tools import Randoms
from selenium.webdriver.support.ui import Select
from tools.Randoms import getRandomDay
import random

#获取表单的元素
    #注册链接
regis_link = (By.LINK_TEXT,'注册')
    #注册的email
regis_email = (By.NAME,"email")
    #注册的密码
regis_passwd = (By.ID,"passwd")
    #注册的重复密码
regis_repasswd = (By.NAME,"repasswd")
    #注册的名字
regis_name = (By.NAME,"name")
    #注册选择的性别 注意这里有两个元素需要采用elements
regis_sexs = (By.NAME,"sex")
    #注册中的选择年
regis_year = (By.NAME,"birthday_year")
    #注册中的选择月
regis_month = (By.NAME,"birthday_month")
    #注册中的选择日
regis_day = (By.NAME,"birthday_day")
    #注册中选择地区
regis_location = (By.XPATH,"/html/body/div[2]/form/ul[2]/li[4]/div[2]/input[3]")
    #注册中选择省份注意这里 ../li[数字]/a表示是哪一个省份
regis_location_province = (By.XPATH,"//ul[@id='list_1']/li")
    #注册中选择地方注意这里 ../li[数字]/a表示是哪一个省份
regis_location_conty = (By.XPATH,"//ul[@id='list_2']/li")
    #选择地方的确定按钮
regis_location_confirm = (By.NAME,"input")
    #注册中的隐私社字号
regis_hide = (By.NAME,"baseinfoprivacy")
    #注册按钮
regis_btn = (By.NAME,"button")
    #点击退出
regis_lg_exit = (By.LINK_TEXT,"退出")
# now = time.strftime('%Y%m%d%H%M%S')
# print(time.gmtime())
# print(now)


# 点击注册链接，跳转到注册页面
def click_regis_link(self):
    self.driver.find_element(*regis_link).click()
# 进行注册的填写 choice_sex=0 表示男 1 表示女
def click_regis_success_exit(self):
    self.driver.find_element(*regis_lg_exit).click()
def operate_regis_page(self,username,password,user_realname,choice_sex=0):
    #填写用户名
    tools.Wait.wait(self.driver,regis_email)
    regis_email1 = self.driver.find_element(*regis_email)
    regis_email1.clear()
    regis_email1.send_keys(username)
    #填写密码
    regis_passwd1 = self.driver.find_element(*regis_passwd)
    regis_passwd1.clear()
    regis_passwd1.send_keys(password)
    #填写重复密码
    regis_repasswd1 = self.driver.find_element(*regis_repasswd)
    regis_repasswd1.clear()
    regis_repasswd1.send_keys(password)
    #填写真实的姓名
    regis_name1 = self.driver.find_element(*regis_name)
    regis_name1.clear()
    regis_name1.send_keys(user_realname)
    #填写性别 
    if choice_sex ==0:
        self.driver.find_elements(*regis_sexs)[0].click()
    else:
        self.driver.find_elements(*regis_sexs)[1].click()
    #填写日期使用了ui库里面的select选择 简化了操作
        #找到元素
    regis_year1 = self.driver.find_element(*regis_year)
    regis_month1 = self.driver.find_element(*regis_month)
    regis_day1 = self.driver.find_element(*regis_day)
        #转化为Select的对象
    s1_year = Select(regis_year1)
    s1_month = Select(regis_month1)
    s1_day = Select(regis_day1) 
        #调用随机数的方法给出正确的日期
    year_value = Randoms.getRandomYear()
    month_value = Randoms.getRandomMonth()
    s1_year.select_by_value(str(year_value))
    s1_month.select_by_value(str(month_value))
    s1_day.select_by_value(str(getRandomDay(year_value, month_value)))
    #填写地区
        #点击选择地区
    self.driver.find_element(*regis_location).click()
        #获取省份的长度
    time.sleep(1)
    province_len = len(self.driver.find_elements(*regis_location_province))
    time.sleep(1)
    num_province = random.randint(1,province_len)
        #获取选择的省份对象
    province_obj = self.driver.find_element_by_xpath("//ul[@id='list_1']/li["+str(num_province)+"]/a")
    province_obj.click()
    time.sleep(1)
    conty_len = len(self.driver.find_elements(*regis_location_conty))
    num_conty = random.randint(1,conty_len)
        #获取市县对象
    conty_obj = self.driver.find_element_by_xpath("//ul[@id='list_2']/li["+str(num_conty)+"]/a")
    conty_obj.click()
    #点击确定
    self.driver.find_element(*regis_location_confirm).click()
    #选择能够查看
    s_hide = Select(self.driver.find_element(*regis_hide))
    s_hide.select_by_value(str(random.randint(0,2)))
    #点击确认按钮 
    self.driver.find_element(*regis_btn).click()