'''
Created on 2018年6月10日
@author: hyt
'''
from selenium import webdriver
import time
import tools.Wait
import os
from selenium.webdriver.common.by import By
from tools import Randoms
from selenium.webdriver.support.ui import Select
from tools.Randoms import getRandomDay
import random
from tools.Wait import wait
#获取注册表单的元素
    #获取email
login_email = (By.NAME,"email")
    #获取密码
login_passwd = (By.NAME,"passwd")
    #是否选中自动登录
login_isautologin = (By.NAME,"remembor")
    #点击登录按钮
login_btn = (By.NAME,"button")
    #退出按钮
login_exit_btn = (By.LINK_TEXT,"退出")
    #验证登录成功里面的元素
login_sucess_confirm = (By.LINK_TEXT,"个人空间")
    #第二个登录页面的确定按钮
login_btn2 = (By.XPATH,"//input[@type='submit']")
    #验证错误登录后的页面信息
login_error_confirm = (By.XPATH,"/html/body/div[3]/font")
    #第三种进入登录的方式
login_btn_page = (By.XPATH,"//div[1]/div[3]/a[2]")
    #第四种进入登录的方式
login_suibiankankan=(By.LINK_TEXT,"随便看看")
    #查看其他所有的用户
user_querys = (By.XPATH,"//span/a/img")

link_more=(By.LINK_TEXT,"更多")
def login_sucess(self,username,password):
    wait(self.driver,login_btn)
    login_email1 = self.driver.find_element(*login_email)
    login_email1.clear()
    login_email1.send_keys(username)
    login_passwd1 = self.driver.find_element(*login_passwd)
    login_passwd1.clear()
    login_passwd1.send_keys(password)
    self.driver.find_element(*login_btn).click()
    
def login_exit(self):
    wait(self.driver,login_exit_btn)
    self.assertEqual(self.driver.find_element(*login_sucess_confirm).text, "个人空间", "登录失败")
    self.driver.find_element(*login_exit_btn).click()
def login_sucess_2(self,username,password):
    wait(self.driver,login_email)
    login_email1 = self.driver.find_element(*login_email)
    login_email1.clear()
    login_email1.send_keys(username)
    login_passwd1 = self.driver.find_element(*login_passwd)
    login_passwd1.clear()
    login_passwd1.send_keys(password)
    self.driver.find_element(*login_btn2).click()
def confirm_long_error1(self):
    self.assertEqual("email或密码错误!",self.driver.find_element(*login_error_confirm).text,"验证失败")
def btn_link_click(self):
    wait(self.driver,login_btn_page)
    self.driver.find_element(*login_btn_page).click()
def login_enter_error(self):
    wait(self.driver,login_suibiankankan)
    self.driver.find_element(*login_suibiankankan).click()
    self.driver.find_elements(*user_querys)[0].click()
    wait(self.driver,link_more)
    self.driver.find_element(*link_more).click()