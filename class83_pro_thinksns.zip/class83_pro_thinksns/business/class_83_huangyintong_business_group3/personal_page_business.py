from selenium.webdriver.common.by import By
from tools.Wait import wait
import time
from selenium import webdriver

#首页的各种元素
    #thinksns_图标
thinssns_picture=(By.XPATH,"/html/body/div[1]/div[1]/a")
    #首页图标
firs_page_link=(By.XPATH,"//ul/li[1]/a")

suibiankank_link=(By.LINK_TEXT,"随便看看")

login_link=(By.LINK_TEXT,"登录")
regis_link=(By.LINK_TEXT,"注册")
help_link=(By.LINK_TEXT,"帮助")

regis_now_link=(By.XPATH,"/html/body/div[2]/div[2]/div[1]/div[2]/div/a/img")

power_link = (By.XPATH,"/html/body/div[5]/div[1]/a")

about_us_link =(By.LINK_TEXT,'关于我们')
connectsomeone_link =(By.LINK_TEXT,"联系方式")
friendship_link =(By.LINK_TEXT,"友情链接")
#首页跳转后验证的各种元素 '随便看看'
suibiankank_link_after = (By.XPATH,"//div[2]/div[1]/span")
#注册跳转后验证的元素 '注册：完善你的个人信息，加入SNS社区'
regis_link_after = (By.XPATH,"/html/body/div[2]/h1")
#登录跳转后验证的元素 ‘登录SNS社区’ /html/body/div[3]/h1
login_link_after = (By.XPATH,"/html/body/div[3]/h1")

#帮助后跳转的验证元素 ‘注册为会员’
help_link_after = (By.XPATH,"/html/body/div[2]/div[1]/div[2]/ul/li[1]/a")

#点击power_link后跳转
power_link_after = (By.XPATH,"/html/body/div[2]/div[1]/nav/ul/li[9]/a")

#下方的连接验证
bottom_right_link_after =(By.XPATH,"/html/body/div[2]/div[2]/div/div[1]")

def click_btn_first_page(self):
    wait(self.driver,firs_page_link)
    self.driver.find_element(*firs_page_link).click()
def confirm_every_page(self):
    #
    click_btn_first_page(self)
    #验证首页的图标
    confirm_function(self,thinssns_picture, firs_page_link, "首页")
    #验证首页
    confirm_function(self,firs_page_link, firs_page_link, "首页")
    #验证随便看看
    confirm_function(self,suibiankank_link, suibiankank_link_after, "随便看看")
    #验证注册
    confirm_function(self,regis_link, regis_link_after, "注册：完善你的个人信息，加入SNS社区")
    #验证登录
    confirm_function(self,login_link, login_link_after, "登录SNS社区")
    #验证帮助
    confirm_function(self,help_link, help_link_after, "注册成为会员")
    #验证立即注册
    click_btn_first_page(self)
    confirm_function(self,regis_now_link, regis_link_after, "注册：完善你的个人信息，加入SNS社区")
    #最新连接
    confirm_function(self,power_link, power_link_after, "合作与生态",0)
    
    #下方的三个按钮
    confirm_function(self,about_us_link, about_us_link, '关于我们')
    confirm_function(self,connectsomeone_link, connectsomeone_link, "联系方式")
    confirm_function(self,friendship_link, friendship_link, "友情链接")
    time.sleep(1)
    
def confirm_function(self,locator1,confirmlocation2,msg,flag=1):
    wait(self.driver,locator1)
    self.driver.find_element(*locator1).click()
    if(flag==0):
        get_handle_confirm(self,confirmlocation2,msg)
    else:
        self.assertEqual(msg,self.driver.find_element(*confirmlocation2).text,"失败")

def get_handle_confirm(self,confirmlocation2,msg):
    current_handle = self.driver.current_window_handle
    handles = self.driver.window_handles
    for handle in handles:
        if current_handle==handle:
            continue
        else:
            self.driver.switch_to_window(handle)
    self.assertEqual(msg,self.driver.find_element(*confirmlocation2).text,"失败")
    self.driver.close()
    self.driver.switch_to_window(current_handle)