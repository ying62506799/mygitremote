from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os
from email._header_value_parser import get_attribute
 
#获取email
# login_email = (By.NAME,"email")
#获取密码
# login_passwd = (By.NAME,"passwd")
#点击登录按钮
# login_btn = (By.NAME,"button")
# 点击上传按钮
fileup_btn = (By.XPATH,"/html/body/div[2]/div[1]/div[2]/ul/li[4]/span/a")
# 点击添普通上传按钮
file_btn = (By.XPATH,"/html/body/div[2]/div[2]/div[2]/ul/li[1]/a/span")
# 点击选择文件按钮
addfile_btn = (By.ID,"fileField_3")
# 点击提交按钮
submit_btn = (By.ID,"submit_button")
submit_button = (By.XPATH,"/html/body/div[2]/div[2]/div[3]/form/div[4]/input[3]")
# 图片名称
picture = (By.XPATH,"/html/body/div[2]/div[2]/div[3]/ul/li[1]/a")
# 登录
def picture_upload(self):
    fileup_btn1 = self.driver.find_element(*fileup_btn)
    fileup_btn1.click()
    time.sleep(2)
    file_btn1 = self.driver.find_element(*file_btn)
    file_btn1.click()
    addfile_btn1 = self.driver.find_element(*addfile_btn)
    addfile_btn1.click()
    os.system(os.getcwd().split("src")[0]+os.sep+"datadriver"+ os.sep+"picture" +os.sep+"UploadFile.exe")
    submit_btn1 = self.driver.find_element(*submit_btn)
    submit_btn1.click()
    submit_button1 = self.driver.find_element(*submit_button)
    submit_button1.click()
    
def confirm_picture_upload(self):
    titles = self.driver.find_elements(*picture)
    list_titles =[]
    for title in titles:
        title = title.get_attribute("title")
        list_titles.append(title)    
    str_list = str(list_titles) 
    print(list_titles)
    print(str_list)
    self.assertIn('timg',str_list)


    
    