
from selenium import webdriver
from selenium.webdriver.common.by import By
from tools.Wait import wait
import time
#定位元素
#更多按钮
more = (By.CSS_SELECTOR,".info>p>span>a")
#心情输入框
input_box =(By.XPATH,".//*[@id='mini-coment']")
#发布按钮
release=(By.XPATH,"html/body/div[2]/div[2]/div[1]/div[2]/div[3]/input")
#我的心情
my_mood=(By.XPATH,"html/body/div[2]/div[2]/div[2]/ul/li[2]/a/span")
#回复按钮
reply=(By.XPATH,".//*/p/a")
#我的心情回复框
reply_box=(By.XPATH,".//*[@class='cGray2 inputReplay]")
#我的心情回复按钮
myreply=(By.XPATH,".//*[@id='button1']")
#退出按钮
exit=(By.XPATH,"html/body/div[1]/div[3]/a[5]")
#系统左侧的心情组件按钮
mood_component=(By.XPATH,"html/body/div[1]/div[3]/a[5]")
#更多心情按钮
more_mood=(By.XPATH,".//*[@id='Fli1']/div[2]/div[1]/h4/span[2]/a")
#回复按钮（好友心情）
friend_mood=(By.XPATH,".//*[@id='Fli1']/div[2]/div[1]/p/a")
#好友心情回复框
friend_reply_box=(By.XPATH,".//*[@id='input1']")
#好友心情回复按钮
friends_reply=(By.XPATH,".//*[@id='button1']")

#方法
def  post_mood(self):
    #找到页面元素
    wait(self.driver, more)
    self.driver.find_element(*more).click()
    time.sleep(1)
    self.driver.find_element(*input_box).clear()
    time.sleep(1)
    self.driver.find_element(*input_box).send_keys("qwer")
    time.sleep(1)
    self.driver.find_element(*release).click()
    #刷新页面
    self.driver.refresh()
    #验证发布是否成功
    #发布心情后的验证点
    release_mood=(By.XPATH,".//*/p")
    release_mood1=self.driver.find_elements(*release_mood)[0].text
    self.assertIn("qwer",release_mood1,"不通过")
    
#     def mymood(self):
#         self.driver.find_element(*my_mood).click()
#         self.driver.find_elements(*reply)[0].click()
#         self.driver.find_elements(*reply_box)[0].send_keys("123456")
#         self.driver.find_element(*myreply).click()
#         self.driver.find_element(*exit).click()
# def friendmood(self):
#     self.driver.find_element(*mood_component).click()
#     self.driver.find_element(*more_mood).click()
#     self.driver.find_element(*mood_component).click()
#     self.driver.find_element(*friend_mood).click()
    
    
    