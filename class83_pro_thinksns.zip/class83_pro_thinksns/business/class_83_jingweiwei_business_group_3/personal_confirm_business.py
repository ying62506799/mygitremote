'''
Created on 2018年6月15日

@author: Administrator
'''
#  这是协议了一个验证的方法
from selenium import webdriver
from selenium.webdriver.common.by import By
from tools import Wait
from test import fork_wait
from tools.Wait import wait

#1定位元素
rizi=(By.XPATH,"/html/body/div[2]/div[1]/div[2]/ul/li[1]/a")



#2方法验证登录后页面是否加载完成
def yanzn(self):
    wait(self.driver, rizi)
    self.driver.find_element(*rizi).click()
    #验证文本是否存在
    rizi3=self.driver.find_element(*rizi).text
    #验证点  比对点，不一样输出什么
    self.assertEqual("日志",rizi3,"不一样")