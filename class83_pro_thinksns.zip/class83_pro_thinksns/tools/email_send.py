#!/usr/bin/python
# -*- coding: UTF-8 -*-
import smtplib
import email.mime.multipart
import email.mime.text
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
#smtphost 服务器的地址 ：smtp.163.com
#sendAddr 发送的地址
#password 发送的第三方密码
#recipientAddrs 接受方的地址
#path 上传的文件的路径
def send_email(smtpHost, sendAddr, password, recipientAddrs, subject='', content=''):
    msg = email.mime.multipart.MIMEMultipart()
    msg['from'] = sendAddr
    msg['to'] = recipientAddrs
    msg['subject'] = subject
    content = content
    txt = email.mime.text.MIMEText(content, 'plain', 'utf-8')
    msg.attach(txt)


    # 添加附件，传送D:/软件/yasuo.rar文件
    part = MIMEApplication(open('D:\\testing\\eclipse\\workplace\\class83_pro_thinksns\\report.zip','rb').read())
    part.add_header('Content-Disposition', 'attachment', filename="elect2.rar")
    msg.attach(part)

    smtp = smtplib.SMTP()
    smtp.connect(smtpHost, '25')
    smtp.login(sendAddr, password)
    smtp.sendmail(sendAddr, recipientAddrs, str(msg))
    print("发送成功！")
    smtp.quit()
