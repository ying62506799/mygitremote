import xlrd
import os
def get_testdata_by_excel(filepath,sheetname='Sheet1'):
    '''
    说明：用来读取filepath指定的excel文件中的sheet，sheet的名字是sheetname
    参数：
          filepath：是一个str，是excel文件的完整路径，包含文本名称
          sheetname：是一个str,指明要打开的sheet的名称
    返回：
          all_content：是一个list，其中的每一个元素，也是一个list，值是excel表
          中的一行数据，一行数据有3个的话，那么list中就有三个元素.
          返回的数据中，第一行是跳过了的。
    例如：
          excel表中的数据是：
           username    password    expected
                         123456    用户"输入用户名"不存在
            admin                  用户名或密码为空
            admin        1234567    用户名或密码错误,您还可以尝试 

         返回的内容是：
             [['', 123456, '用户"输入用户名"不存在'],['admin', '', '用户名或密码为空'],['admin', 1234567, '用户名或密码错误,您还可以尝试 ']]
    
    '''
    book = xlrd.open_workbook(filepath)
#     sheet = book.sheet_by_index(0)  #sheet的index是从0开始的
    sheet = book.sheet_by_name(sheetname)
    all_content = []
    for i in range(1,sheet.nrows):   #跳过第1行
        row_content = []
        for j in range(sheet.ncols):
            cell = sheet.cell_value(i, j)
            ctype = sheet.cell(i, j).ctype  # 获取单元格的数据类型
            #把一行中所有的列添加到row_content   
            if(ctype == 2 and cell % 1 == 0):  # 如果单元格里数据是整型
                cell = int(cell)  
            row_content.append(cell) 
        #print(row_content)
        all_content.append(row_content) 
    return all_content
''' 
这是是可以写入数据 通过 传入一个列表进行写入数据 列表中存放的是一个字典。
'''
