import random  

def getRandomName():
    xing='赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜'  
    ming='豫章故郡洪都新府星分翼轸地接衡庐襟三江而带五湖反对方的身份方式时代发生的范加尔我房间开始了疯狂的是否回款是垃圾啊废话额划分为秋风撒打捆损失打开 '  
    X=random.choice(xing)  
    M="".join(random.choice(ming) for i in range(2))  
    return X+M
def getRandomYear():
    return random.randint(1930,2009)
def getRandomMonth():
    return random.randint(1,12)
def getRandomDay(year,month):
    if month in (1,3,5,7,8,10,12):
            return random.randint(1,31)
    elif month in (4,6,9,11):
        return random.randint(1,30)
    else:
        if year %400==0 or(year%4==0 and year%100!=0):
            return random.randint(1,29)
        else:
            return random.randint(1,28)