from selenium import webdriver
import time
import tools.getTC
from tools import getTC

def get_driver(file_path,sheet_name='Sheet1'):
    type = getTC.get_testdata_by_excel(file_path, sheet_name)
    if type[0][0] =='firefox':
        driver = webdriver.Firefox()
    elif type[0][0]=='chrome':
        driver = webdriver.Chrome()
    else:
        driver = webdriver.Ie()
    return driver
