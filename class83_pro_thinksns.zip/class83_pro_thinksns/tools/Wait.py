from  selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
#这个是处理时间等待的处理器 前面 有2个参数 
#driver 表示 驱动 Locator表示 一个元祖元素的值 后面两个参数可以不用设置。
def wait(driver,Locator,timeout=20,pertime=0.5):
    #注意这里的Locator是一个元祖 注意不要是用*
    WebDriverWait(driver, timeout, pertime).until(EC.presence_of_element_located,(Locator))