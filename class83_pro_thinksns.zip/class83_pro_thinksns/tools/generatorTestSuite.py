import unittest,os
from tools import getTC
def gen_test_suite(pattern1):
    testunit = unittest.TestSuite()  #定义一个suite
    # 定义测试文件查找的目录
    test_dir = os.getcwd().split("tools")[0]+os.sep+'src'
#     test_suite_select = os.getcwd().split("tools")[0]+os.sep+"datadriver"+os.sep+"suite_data"+os.sep+"test_suite_select.xlsx"
#         # 注意：pattern，用来匹配/bwf目录下哪些用例加入本次运行\
#     list2 = []
#     list1 = getTC.get_testdata_by_excel(test_suite_select)
#     for i in list1:
#         if i[1] == '✔':
#             list2.append(i[0])
    discover = unittest.defaultTestLoader.discover(test_dir,pattern=pattern1,top_level_dir=None)
    # discover 方法筛选出来的用例，循环添加到测试套件中
    for test_suite in discover:  #discover是多个.py文件的一堆测试
        for test_case in test_suite: #一个文件中的测试用例（test开头的测试用例）
                        testunit.addTests(test_case)
    return testunit
    