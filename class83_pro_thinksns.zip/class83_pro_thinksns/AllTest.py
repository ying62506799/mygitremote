'''
Created on 2018年6月10日

@author: hyt
'''
from tools.generatorTestSuite import gen_test_suite
from tools.HTMLTestRunner import HTMLTestRunner
import time
import os
from tools import email_send
from tools import zip_dir
import unittest
if __name__=="__main__":
    now = time.strftime("%Y-%m-%d_%H_%M_%S")
    reportpath= os.getcwd()+os.sep+'report'+os.sep+now+'_result.html'
    suite = gen_test_suite("thinksns*.py")
    fp = open(reportpath, 'wb')
    HTMLTestRunner()
    runner = HTMLTestRunner(stream=fp,
                            title='thinsns自动化测试报告',
                            description='用例执行情况：',)
    runner.run(suite)
    #获取路径
    data_report_path = os.getcwd()+os.sep+"report"
    zip_dir.zip_dir(data_report_path, "report.zip")
    try:
        subject = 'Python 测试邮件'
        content = '这是一封来自 Python 编写的测试邮件。'
        email_send.send_email('smtp.163.com', 'a337205241@163.com', 'ying225500111', '337205241@qq.com', "发送一份邮件", "给你一份邮件")
    except Exception as err:
        print(err)
