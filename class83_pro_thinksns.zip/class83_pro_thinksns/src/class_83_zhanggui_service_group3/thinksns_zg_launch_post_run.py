# coding=UTF-8
'''
Created on 2018年6月19日

@author: Administrator
'''
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from tools.Wait import wait
from business.class_83_huangyintong_business_group3.login_business import login_sucess
import random
import time

class Test12(unittest.TestCase):


    def setUp(self):
        
        self.driver=webdriver.Chrome()
        self.driver.get("http://203.195.235.31/thinksns/index.php")

    def tearDown(self):
        self.driver.quit()
    def test_launchvote(self):
        login_sucess(self,"1@1.com", "123456")
        #用户1登录
        self.driver.find_element_by_xpath("html/body/div[2]/div[1]/div[2]/ul/li[6]/span/a").click()
        #点击发起投票 进入发起投票主页
        for i in range(0,10):
            self.driver.find_element_by_xpath(".//*[@id='add_more']").click()
            
            #点击添加候选项至20个
        self.driver.find_element_by_xpath(".//*[@id='title']").send_keys("test")
        #填写投票主题
        self.driver.find_element_by_xpath(".//*[@id='tog_explain']").click()
        
        self.driver.find_element_by_xpath(".//*[@id='vote_explain']/div[2]/textarea").send_keys("test")
        #点击添加投票详细说明
        
        elements=self.driver.find_elements_by_xpath(".//*[@id='textfield3']")
        #获取候选项个数，得到一个elements列表
        for i in range(0,20):
            elements[i].send_keys(i+1) 
        #遍历列表并填写候选项
        self.driver.find_element_by_xpath("html/body/div[2]/div[2]/div[2]/div/form/ul/li[29]/div[2]/input").click()
        #点击发起投票按钮
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/div[3]/form/ul/li[3]/div[4]/input").click()
        #找到要投的按钮并点击
        self.driver.find_element_by_xpath("html/body/div[2]/div[2]/div[2]/div[3]/form/div/input").click()
        time.sleep(3)
        #找到投票按钮并点击
        self.driver.find_element_by_xpath("/html/body/div/div[3]/a[5]").click()
        
        #找到页面上的退出按钮并点击退，退回登录页面
        time.sleep(2)
        login_sucess(self,"2@1.com", "123456")
        #用户2登录
        self.driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/ul/li[6]/a").click()
        #点击投票按钮，跳转到好友的投票默认页面
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[3]/div[2]/ul/li/div/div[3]/a").click()
        #找到去投票按钮并点击，跳转到该投票详情页面
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/div[3]/form/ul/li[3]/div[4]/input").click()
        #找到要投的按钮并点击
        self.driver.find_element_by_xpath("html/body/div[2]/div[2]/div[2]/div[3]/form/div/input").click()
        time.sleep(3)
        #找到投票按钮并点击
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/div[5]/div/div[2]/textarea").send_keys("test")
        #找到投票详情页面的评论输入框输入“test”
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/div[5]/div/div[2]/input").click()
        #点击发表评论
        self.driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/ul/li[6]/a").click()
        #点击投票按钮，跳转到好友的投票默认页面
        self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[3]/div[2]/ul/li/div/div[3]/a").click()
        #找到去投票按钮并点击，跳转到该投票详情页面
        validate=(By.XPATH,"/html/body/div[2]/div[2]/div[2]/div[3]/form/span")
        self.driver.find_element(*validate).click()
        validate=self.driver.find_element(*validate).text
     
       
        self.assertEqual("您已经投过票",validate,"测试通过")
        print("成功")
        
        
        
        
        
        
        
        
        
