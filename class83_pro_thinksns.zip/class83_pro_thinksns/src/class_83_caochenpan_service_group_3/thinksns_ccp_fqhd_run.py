'''
Created on 2018年6月19日

@author: Administrator
'''
import unittest
import os
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from business.class_83_huangyintong_business_group3.login_business import login_sucess
import time



class Test_CCP(unittest.TestCase):


    def setUp(self):
        self.driver=webdriver.Chrome()
         #隐式等待10秒
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        self.driver.get("http://203.195.235.31/thinksns/index.php")
        
    def tearDown(self):
        self.driver.quit()
    def testFqhd(self):
       
        #调用登录
        login_sucess(self,"user01@cc.user", "123456")
        #定位活动发起
        self.driver.find_element_by_xpath("/html/body/div[2]/div[1]/div[2]/ul/li[8]/span/a").click()
        #定位活动名称
        self.driver.find_element_by_xpath("//*[@id=\"title\"]").send_keys("大梦初醒")
        #定位活动地点
        self.driver.find_element_by_xpath("//*[@id=\"address\"]").send_keys("四川成都")
        #定位活动分类
        selet1 = self.driver.find_element_by_xpath("//*[@id=\"type\"]")
        sh1 = Select(selet1)
        sh1.select_by_value("1")
        #定位活动开始时间
        time.sleep(2)
        self.driver.find_element_by_xpath("//*[@id=\"sTime\"]").click()
        self.driver.find_element_by_xpath("//*[@id=\"rdates\"]/div[26]").click()
        #定位活动结束时间
        time.sleep(2)
        self.driver.find_element_by_xpath("//*[@id=\"eTime\"]").click()
        self.driver.find_element_by_xpath("//*[@id=\"rdates\"]/div[27]").click()
        #定位报名截止时间
        self.driver.find_element_by_xpath("//*[@id=\"deadline\"]").click()
        self.driver.find_element_by_xpath("//*[@id=\"rdates\"]/div[25]").click()
        #定位活动介绍
        self.driver.find_element_by_xpath("/html/body").click()
        self.driver.switch_to_frame(self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/div/div/form/ul/li[9]/div[2]/table/tbody/tr[2]/td/table/tbody/tr/td/iframe"))
        self.driver.find_element_by_xpath("/html/body").send_keys("让我们一起打个牌睡个觉")
        #点击确认发起按钮
        self.driver.switch_to_default_content()
        
        self.driver.find_element_by_xpath("//*[@id=\"button\"]").click()
        time.sleep(3)
        #退出弹框
        self.driver.find_element_by_xpath("//*[@id='ym-tl']/div/div/div[2]/div[3]").click()
        #再次点击确认发起
        self.driver.find_element_by_xpath("//*[@id=\"button\"]").click()
        time.sleep(3)
        #验证活动介绍
        t1 = self.driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[3]/div[2]/div[2]/div").text
        self.assertEqual(t1, "让我们一起打个牌睡个觉", '失败')
       
        