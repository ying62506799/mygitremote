'''
Created on 2018年6月11日

@author: hyt
'''
import unittest
from tools.getDriverAnduUrl import get_driver
import time
from tools import Randoms, getTC
import random
import os
from business.class_83_huangyintong_business_group3 import regis_business,\
    login_business
from business.class_83_huangyintong_business_group3.regis_business import click_regis_success_exit,\
    click_regis_link

class TestThinksnsLogin(unittest.TestCase):
    def setUp(self):
        path1 = os.getcwd().split("src")[0]+os.sep+"datadriver/driver_type/driver_type.xlsx"
        path2 = os.getcwd().split("src")[0]+os.sep+"datadriver/regisdata/users.xlsx"
        path3 = os.getcwd().split("src")[0]+os.sep+"datadriver/regisdata/user2_nouse.xlsx"
        self.driver = get_driver(path1)
        self.driver.get('http://203.195.235.31/thinksns/index.php')
        self.driver.maximize_window()
        self.driver.implicitly_wait(30)
        self.list1 = getTC.get_testdata_by_excel(path2,"Sheet1")
        self.list2 = getTC.get_testdata_by_excel(path3,"Sheet1")
    def tearDown(self):
        self.driver.quit()
    def test_login_success(self):
        for i in range(len(self.list1)):
            login_business.login_sucess(self,self.list1[i][0], self.list1[i][1])
            login_business.login_exit(self)
#         getTC.get_testdata_by_excel(filepath, sheetname)
    def test_login_success02(self):
        for i in range(len(self.list1)):
            login_business.btn_link_click(self)
            login_business.login_sucess_2(self,self.list1[i][0], self.list1[i][1])
            login_business.login_exit(self)
    def test_login_error01(self):
        for i in range(len(self.list2)):
            login_business.login_sucess(self,self.list2[i][0],self.list2[i][1])
            login_business.confirm_long_error1(self)
            login_business.login_sucess_2(self,self.list2[i][0], self.list2[i][1])
            login_business.confirm_long_error1(self)
            time.sleep(1)
            self.driver.back()
            time.sleep(1)
            self.driver.back()
            print(self.driver.current_url)
#     def test_login_error02(self):
    def test_login_error02(self):
        login_business.btn_link_click(self)
        for i in range(len(self.list2)):
            login_business.login_sucess_2(self,self.list2[i][0], self.list2[i][1])
            login_business.confirm_long_error1(self)
    def test_login_error03(self):
        login_business.login_enter_error(self)
        time.sleep(2)
        for i in range(len(self.list2)):
            login_business.login_sucess_2(self,self.list2[i][0], self.list2[i][1])
            login_business.confirm_long_error1(self)
