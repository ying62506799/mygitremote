'''
Created on 2018年6月10日

@author: hyt
'''
import unittest
from tools.getDriverAnduUrl import get_driver
import time
from tools import Randoms, getTC
import random
import os
from business.class_83_huangyintong_business_group3 import regis_business
from business.class_83_huangyintong_business_group3.regis_business import click_regis_success_exit,\
    click_regis_link
class TestThinksnsRegis(unittest.TestCase):
    
    def setUp(self):
        path1 = os.getcwd().split("src")[0]+os.sep+"datadriver/driver_type/driver_type.xlsx"
        self.driver = get_driver(path1)
        self.driver.get('http://203.195.235.31/thinksns/index.php')
        self.driver.maximize_window()
        self.driver.implicitly_wait(30)
     
    def tearDown(self):
        time.sleep(2)
        self.driver.quit()
    #正向有效的注册测试 注册5个随机的账号并存放在
    def test_regis_success(self):
        userdata=[]
        regis_business.click_regis_link(self)
        for i in range(5):
            user={}
            now = time.strftime('%Y%m%d%H%M%S')
            username = "user"+str(now)+"@qq.com"
            passwd = str(random.randint(1000000,5000000))
            
            user_realname = Randoms.getRandomName()
            chioce_sex=random.randint(0,1)
            regis_business.operate_regis_page(self,username, passwd, user_realname, chioce_sex)
            click_regis_success_exit(self)
            time.sleep(1)
            click_regis_link(self)
            time.sleep(1)
            user["username"]=username
            user["password"]=passwd
            userdata.append(user)
