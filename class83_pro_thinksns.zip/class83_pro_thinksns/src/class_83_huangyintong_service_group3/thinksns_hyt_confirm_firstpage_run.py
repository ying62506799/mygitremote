'''
Created on 2018年6月16日

@author: 33720
'''
import unittest
import os
from tools.getDriverAnduUrl import get_driver
from business.class_83_huangyintong_business_group3 import personal_page_business

class Test(unittest.TestCase):


    def setUp(self):
        path1 = os.getcwd().split("src")[0]+os.sep+"datadriver/driver_type/driver_type.xlsx"
        self.driver = get_driver(path1)
        self.driver.get('http://203.195.235.31/thinksns/index.php')
        self.driver.maximize_window()
        self.driver.implicitly_wait(30)
    def tearDown(self):
        self.driver.quit()
    def test_confirm_firtpage(self):
        personal_page_business.confirm_every_page(self)