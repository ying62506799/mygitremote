'''
Created on 2018年6月15日

@author: Administrator
'''
#调用登录的方法
from business.class_83_huangyintong_business_group3 import login_business
from business.class_83_jingweiwei_business_group_3 import personal_confirm_business
from selenium import webdriver
import unittest
from selenium.webdriver.common.by import By
import time
import os
from selenium.webdriver.support.select import Select
import random
#定位
log_button=(By.XPATH,"html/body/div[2]/div[1]/div[2]/ul/li[1]/a")#日志按钮
Publish_buttno=(By.XPATH,"html/body/div[2]/div[1]/div[2]/ul/li[1]/span/a")#发表日志按钮
title_loc=(By.XPATH,".//*[@id='title']")#日志标题
content_loc=(By.XPATH,"/html/body")#内容框定位
post_button=(By.XPATH,"html/body/div[2]/div[2]/div[2]/form/div[2]/ul/li[7]/div[2]/input[2]")#发表按钮
journalass=(By.XPATH,"html/body/div[2]/div[2]/div[2]/div/div[2]/div[1]/h1/strong")#发表日志验证按钮
mylog=(By.XPATH,"/html/body/div[2]/div[2]/div[2]/ul/li[2]/a/span")#我的日志
fenleiguanli_button=(By.XPATH,"/html/body/div[2]/div[2]/div[4]/div[1]/div[2]/div[1]/span/a")#分类管理按钮
fenleishuru_loc=(By.XPATH,".//*[@id='insertCategory']")#添加分类输入框
addfenlri_button=(By.XPATH,".//*[@id='button']")#增加分类按钮
fenliass=(By.XPATH,".//*[@id='cate2']/div[1]/span/input")#增加分类按钮
inputA=(By.TAG_NAME,"body")
fanhuirizhi=(By.XPATH,"html/body/div[2]/div[2]/div[2]/div/div/a")
zhuyeass=(By.XPATH,"html/body/div[2]/div[2]/div[4]/div[1]/div[2]/ul/li[3]/a")

ifm=(By.XPATH,"/html/body/div[2]/div[2]/div[2]/form/div[2]/ul/li[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr/td/iframe")

class Test(unittest.TestCase):


    def setUp(self):
        #打开浏览器
        self.driver = webdriver.Chrome()
        self.driver.get('http://203.195.235.31/thinksns/index.php')

    def tearDown(self):
        time.sleep(3)
        self.driver.quit()
    def test_log_in_01(self):
        login_business.login_sucess(self,"123456@qq.com","123456")
        personal_confirm_business.yanzn(self)
        
    def test_login_postrizi_02(self):#用户123456@qq.com登录发表日志
        driver=self.driver
        login_business.login_sucess(self,"123456@qq.com","123456")
        driver.find_element(*log_button).click()       
        driver.find_element(*Publish_buttno).click()
        driver.find_element(*title_loc).send_keys("你好")
        time.sleep(2)
        driver.switch_to_frame(self.driver.find_element(*ifm))
        driver.find_element(*content_loc).send_keys("holle")       
        time.sleep(1)
        driver.switch_to_default_content()
        driver.find_element(*post_button).click()
        journalname=self.driver.find_element(*journalass).text
        self.assertEqual("你好", journalname, "错误")
    def test_login_addfenlei_03(self):#添加日志分类
        driver=self.driver
        login_business.login_sucess(self,"123456@qq.com","123456")
        driver.find_element(*log_button).click()
        driver.find_element(*mylog).click()
        time
        driver.find_element(*fenleiguanli_button).click()
        str1 = str(random.randint(100000,200000))
        driver.find_element(*fenleishuru_loc).send_keys("漂亮3"+str1)
        driver.find_element(*addfenlri_button).click()
        driver.find_element(*fanhuirizhi).click()
        
        print(driver.find_element(*inputA).text)
        str2 = ""
        for i in driver.find_element(*inputA).text:
            str2 = str2 + i;
#         if "漂亮3" in driver.find_element(*inputA).text:
#             print("ok")
#         else:
#             print("没有漂亮")
        print(str2) 
        self.assertIn("漂亮3", str2, "失败") 
    def test_tongzi_04(self):    #通知页面验证
        driver=self.driver   
        xiaoxi_button=(By.XPATH,"html/body/div[1]/div[2]/ul/li[5]/a")
        tongzi_button=(By.XPATH,"html/body/div[2]/div[2]/div[2]/ul/li[3]/a/span")          
        login_business.login_sucess(self,"123456@qq.com","123456")
        driver.find_element(*xiaoxi_button).click()
        driver.find_element(*tongzi_button).click()
        actual=driver.find_element(*tongzi_button).text  
        expected='通知'   #预期输入
        self.assertEqual(expected, actual)
        self.driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[2]/ul/li[4]/a").click()
        self.driver.find_element(By.XPATH, "//*[@id='ui-fs']/div[2]/a").click()
        time.sleep(2)
        self.driver.find_element(By.XPATH, "//*[@id='ui-fs']/div[4]/div[2]/div[2]/a").click()
        self.driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[3]/div/form/ul/li[2]/div[2]/input").send_keys("主题1")
        self.driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[3]/div/form/ul/li[3]/div[2]/textarea").send_keys("内容1")
        self.driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[3]/div/form/ul/li[4]/div[2]/input[1]").click()
    def test_rizi2_05(self): #选择发表日志   下拉列表选择 
        driver =self.driver  
        login_business.login_sucess(self,"123456@qq.com","123456") 
        driver.find_element(*log_button).click()       
        driver.find_element(*Publish_buttno).click()
        selector = Select(driver.find_element_by_id("select"))
        selector.select_by_value("4")   
        driver.find_element(*title_loc).send_keys("你好01")
        time.sleep(2)
        #driver.switch_to_frame(self.driver.find_element(By.XPATH,"/html/body/div[2]/div[2]/div[2]/form/div[2]/ul/li[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr/td/iframe"))
        driver.switch_to_frame(self.driver.find_element(*ifm))
        driver.find_element(*content_loc).send_keys("holle")       
        time.sleep(1)
        driver.switch_to_default_content()
        time.sleep(1)
        driver.find_element(By.ID,"ajax_upload_attach_button").click()
        os.system(os.getcwd().split("src")[0]+"datadriver"+os.sep+"upload"+os.sep+"UploadFile.exe")
        
        selector = Select(driver.find_element_by_name("privacy"))
        selector.select_by_value("1")
        time.sleep(1)
        selector = Select(driver.find_element_by_id("cc"))
        selector.select_by_value("2") 
        time.sleep(1)
        driver.find_element(*post_button).click()
        journalname=self.driver.find_element(*journalass).text
        self.assertEqual("你好01", journalname, "错误")
        
        


