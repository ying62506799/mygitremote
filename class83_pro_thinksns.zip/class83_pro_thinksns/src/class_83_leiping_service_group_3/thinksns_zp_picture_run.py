import unittest
#调用登录的方法
from business.class_83_huangyintong_business_group3 import login_business
from business.class_83_leiping_business_group_3 import picture_fileup_business

from selenium import webdriver
import time

class Test(unittest.TestCase):


    def setUp(self):
        #打开浏览器
        self.driver = webdriver.Chrome()
        self.driver.get('http://203.195.235.31/thinksns/index.php')

    def tearDown(self):
        time.sleep(3)
        self.driver.quit()

    def test_picture_loadup(self):
        login_business.login_sucess(self,"test1@qq.com","123456")
        picture_fileup_business.picture_upload(self)
        picture_fileup_business.confirm_picture_upload(self)
   # def test_login_postrizi_02(self):