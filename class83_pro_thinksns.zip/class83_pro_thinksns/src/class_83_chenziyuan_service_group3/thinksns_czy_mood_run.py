'''
Created on 2018年6月19日

@author: Administrator
'''
import unittest
from business.class_83_huangyintong_business_group3 import login_business
from business.class_83_chenziyuan_business_group3 import emotion_business
from selenium import webdriver

class Test(unittest.TestCase):


    def setUp(self):
        self.driver=webdriver.Chrome()
        self.driver.get("http://203.195.235.31/thinksns/index.php")
        self.driver.maximize_window()
        
    def tearDown(self):
        self.driver.quit()

    def test_post_mood(self):
        login_business.login_sucess(self,"1111@qq.com","123456")
        emotion_business.post_mood(self)
#    def test_mymood(self):
#        emotion_business.mymood(self)
        